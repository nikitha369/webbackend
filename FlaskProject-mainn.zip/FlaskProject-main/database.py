import sqlite3

# Function to create database tables
def create_tables():
    con = sqlite3.connect('mydatabase.db')
    cur = con.cursor()
    cur.execute('''CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY,
                    email TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    full_name TEXT NOT NULL
                )''')
    cur.execute('''CREATE TABLE IF NOT EXISTS tasks (
                    id INTEGER PRIMARY KEY,
                    task_name TEXT NOT NULL,
                    description TEXT,
                    due_date DATE,
                    assigned_to TEXT NOT NULL,
                    FOREIGN KEY (assigned_to) REFERENCES users (email)
                )''')
    con.commit()
    con.close()
