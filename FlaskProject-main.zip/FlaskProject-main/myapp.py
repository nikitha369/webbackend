# Add necessary imports
from flask import Flask, redirect, url_for, request, render_template, session

# Initialize the Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Database connection
import sqlite3

con = sqlite3.connect('mydatabase.db', check_same_thread=False)
cur = con.cursor()

# Define routes and functions...

# Login route
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
        cur.execute("SELECT * FROM users WHERE email = ? AND password = ?", (email, password))
        user = cur.fetchone()
        if user:
            session['user'] = email
            return redirect(url_for("tasks"))
        else:
            return render_template("login.html", error="Incorrect email or password")
    else:
        return render_template("login.html")

# Register route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        full_name = request.form['full_name']
        cur.execute("SELECT * FROM users WHERE email = ?", [email])
        existing_user = cur.fetchone()
        if existing_user:
            return render_template("register.html", error="User already exists")
        else:
            cur.execute("INSERT INTO users (email, password, full_name) VALUES (?, ?, ?)", (email, password, full_name))
            con.commit()
            session['user'] = email
            return redirect(url_for("tasks"))
    else:
        return render_template("register.html")

# Logout route
@app.route("/logout")
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

# Tasks route
@app.route("/tasks")
def tasks():
    if 'user' in session:
        # Fetch tasks for the logged-in user from the database
        cur.execute("SELECT * FROM tasks WHERE assigned_to = ?", [session['user']])
        tasks = cur.fetchall()
        return render_template("tasks.html", tasks=tasks)
    else:
        return redirect(url_for('login'))

# User details route
@app.route("/user_details")
def user_details():
    if 'user' in session:
        email = session['user']
        cur.execute("SELECT email, full_name FROM users WHERE email = ?", [email])
        user = cur.fetchone()
        return render_template("user_details.html", user=user)
    else:
        return redirect(url_for('login'))

# Add tasks route
@app.route("/add_task", methods=["GET", "POST"])
def add_task():
    if request.method == "POST":
        # Fetch form data
        task_name = request.form["task_name"]
        description = request.form["description"]
        due_date = request.form["due_date"]
        assigned_to = session['user']  # Assign the task to the logged-in user
        # Insert the task into the database
        cur.execute("INSERT INTO tasks (task_name, description, due_date, assigned_to) VALUES (?, ?, ?, ?)",
                    (task_name, description, due_date, assigned_to))
        con.commit()
        return redirect(url_for("tasks"))
    else:
        return render_template("add_task.html")

# Edit task route
@app.route("/edit_task/<int:task_id>", methods=["GET", "POST"])
def edit_task(task_id):
    if 'user' in session:
        if request.method == "POST":
            # Fetch form data
            task_name = request.form["task_name"]
            description = request.form["description"]
            due_date = request.form["due_date"]
            # Update the task in the database
            cur.execute("UPDATE tasks SET task_name=?, description=?, due_date=? WHERE id=? AND assigned_to=?",
                        (task_name, description, due_date, task_id, session['user']))
            con.commit()
            return redirect(url_for("tasks"))
        else:
            # Fetch the task from the database
            cur.execute("SELECT * FROM tasks WHERE id=? AND assigned_to=?", (task_id, session['user']))
            task = cur.fetchone()
            if task:
                return render_template("edit_task.html", task=task)
            else:
                return "Task not found", 404
    else:
        return redirect(url_for('login'))

# Delete task route
@app.route("/delete_task/<int:task_id>", methods=["POST"])
def delete_task(task_id):
    if 'user' in session:
        # Delete the task from the database
        cur.execute("DELETE FROM tasks WHERE id=? AND assigned_to=?", (task_id, session['user']))
        con.commit()
        return redirect(url_for("tasks"))
    else:
        return redirect(url_for('login'))

if __name__ == "__main__":
    app.run(debug=True)
