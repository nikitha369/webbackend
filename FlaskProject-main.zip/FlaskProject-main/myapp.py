from flask import Flask, redirect, url_for, request, render_template, session
import sqlite3
from random import randint

# Make a connection to database
con = sqlite3.connect('mydatabase.db', check_same_thread=False)
cur = con.cursor()

# Creating an instance of the Flask Class
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a secure secret key

# Create unique user IDs
def unique_id():
    seed = 23  # Set your desired seed value
    while True:
        yield seed
        seed += 1

unique_sequence = unique_id()

# Define routes
@app.route("/")
def home():
    return render_template("items.html", content="Passing this from backend")

@app.route("/login", methods=["POST", "GET"])
def login():
    if request.method == "POST":
        user = request.form["email"]
        session['user'] = user
        return redirect(url_for("user", usr=user))
    else:
        return render_template("login.html")

@app.route('/read-form', methods=['POST']) 
def read_form(): 
    if request.method == 'POST':
        if request.form['submit_button'] == 'submit':
            data = request.form
            cur.execute("SELECT * FROM users WHERE email = ?", [data["userEmail"]])
            result = cur.fetchone()
            if result and result[1] == data["userEmail"] and result[2] == data["userPassword"]:
                session['user'] = data["userEmail"]
                return redirect(url_for("user", usr=data["userEmail"]))
            elif result and result[1] == data["userEmail"] and result[2] != data["userPassword"]:
                return render_template("login.html", content="Incorrect Password")
            else:
                return render_template("login.html", content="User does not exist")
        elif request.form['submit_button'] == 'register':
            data = request.form
            cur.execute("SELECT * FROM users WHERE email = ?", [data["userEmail"]])
            result = cur.fetchone()
            if result:
                return render_template("login.html", content="User Already Exists")
            else:
                id = next(unique_sequence)
                cur.execute("INSERT INTO users VALUES(?,?,?)", (id, data["userEmail"], data["userPassword"]))
                con.commit()
                return redirect(url_for("user", usr=data["userEmail"]))

@app.route("/users")
def display_users():
    cur.execute('SELECT * FROM users')
    rows = cur.fetchall()
    return render_template('showusers.html', usr=rows)

@app.route('/items')
def items():
    return render_template('items.html')

@app.route("/<usr>")
def user(usr):
    return render_template("user.html", usr=usr)

# CRUD operations for tasks
@app.route("/tasks", methods=["GET", "POST"])
def tasks():
    if 'user' not in session:
        return redirect(url_for('login'))
    if request.method == "GET":
        # Fetch all tasks from the database
        cur.execute("SELECT * FROM tasks")
        rows = cur.fetchall()
        return render_template("tasks.html", tasks=rows)
    elif request.method == "POST":
        # Get task details from the form
        task_name = request.form["task_name"]
        description = request.form["description"]
        due_date = request.form["due_date"]
        assigned_to = session['user']  # Assign task to current user
        
        # Insert the task into the database
        cur.execute("INSERT INTO tasks (task_name, description, due_date, assigned_to) VALUES (?, ?, ?, ?)",
                    (task_name, description, due_date, assigned_to))
        con.commit()
        
        # Redirect the user back to the tasks page
        return redirect(url_for("tasks"))


@app.route("/tasks/<int:task_id>", methods=["GET", "POST", "PUT", "DELETE"])
def task(task_id):
    if request.method == "GET":
        cur.execute("SELECT * FROM tasks WHERE id = ?", [task_id])
        row = cur.fetchone()
        return render_template("task.html", task=row)
    elif request.method == "POST":
        data = request.form
        cur.execute("UPDATE tasks SET task_name=?, description=?, due_date=?, assigned_to=? WHERE id=?",
                    (data["task_name"], data["description"], data["due_date"], data["assigned_to"], task_id))
        con.commit()
        return redirect(url_for("tasks"))
    elif request.method == "PUT":
        data = request.form
        cur.execute("INSERT INTO tasks (task_name, description, due_date, assigned_to) VALUES (?, ?, ?, ?)",
                    (data["task_name"], data["description"], data["due_date"], data["assigned_to"]))
        con.commit()
        return redirect(url_for("tasks"))
    elif request.method == "DELETE":
        cur.execute("DELETE FROM tasks WHERE id = ?", [task_id])
        con.commit()
        return redirect(url_for("tasks"))

if __name__ == "__main__":
    app.run(host='0.0.0.0', debug=True)
